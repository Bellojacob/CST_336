let head = document.querySelector("h1")
head.style.color = "red";